"""
CONTAX - Base de datos multi-tenant
Cada CONTADOR (licenciatario) tiene su propio SCHEMA de Postgres.
El schema 'public' contiene tablas globales: contadores, licencias, usuarios admin.
Cada schema 'contador_<id>' contiene: clientes, facturas, compras, asientos, etc.
"""
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, declarative_base
from contextlib import contextmanager
from app.core.config import settings

engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """Dependency FastAPI - sesión global (schema public)."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@contextmanager
def tenant_session(schema_name: str):
    """
    Context manager para obtener una sesión que opera dentro
    del schema de un contador específico (multi-tenant).

    Uso:
        with tenant_session("contador_1") as db:
            db.query(Cliente).all()
    """
    db = SessionLocal()
    try:
        # search_path: primero el schema del tenant, luego public (para tablas compartidas)
        db.execute(f'SET search_path TO "{schema_name}", public')
        yield db
    finally:
        db.execute('SET search_path TO public')
        db.close()


def create_tenant_schema(schema_name: str):
    """
    Crea un nuevo schema para un contador y todas sus tablas (Tenant Base).
    Se llama cuando se registra un nuevo contador/licenciatario.
    """
    from app.models.tenant_models import TenantBase

    with engine.connect() as conn:
        conn.execute(f'CREATE SCHEMA IF NOT EXISTS "{schema_name}"')
        conn.commit()

    # Crear las tablas del tenant dentro de ese schema
    with engine.connect() as conn:
        conn.execute(f'SET search_path TO "{schema_name}"')
        conn.commit()
        TenantBase.metadata.create_all(bind=conn, checkfirst=True)
