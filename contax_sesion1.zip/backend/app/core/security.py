"""
CONTAX - Seguridad
- Hash de contraseñas (bcrypt)
- JWT para autenticación (access + refresh tokens)
- Encriptación simétrica (Fernet) para credenciales del SRI de cada cliente
"""
from datetime import datetime, timedelta, timezone
from typing import Optional
from passlib.context import CryptContext
from jose import jwt, JWTError
from cryptography.fernet import Fernet
from app.core.config import settings

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


# =========================================================
# CONTRASEÑAS
# =========================================================

def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


# =========================================================
# JWT TOKENS
# =========================================================

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (
        expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    to_encode.update({"exp": expire, "type": "access"})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def create_refresh_token(data: dict) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire, "type": "refresh"})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def decode_token(token: str) -> Optional[dict]:
    try:
        return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
    except JWTError:
        return None


# =========================================================
# ENCRIPTACIÓN DE CREDENCIALES SRI
# =========================================================
# Cada cliente tiene clave SRI guardada encriptada con Fernet (simétrica).
# La FERNET_KEY vive en variables de entorno, NUNCA en el código.

def _get_fernet() -> Fernet:
    key = settings.FERNET_KEY
    if not key:
        raise RuntimeError(
            "FERNET_KEY no configurada. Generar con: "
            "python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\""
        )
    return Fernet(key.encode() if isinstance(key, str) else key)


def encriptar_clave_sri(clave_plana: str) -> str:
    f = _get_fernet()
    return f.encrypt(clave_plana.encode()).decode()


def desencriptar_clave_sri(clave_encriptada: str) -> str:
    f = _get_fernet()
    return f.decrypt(clave_encriptada.encode()).decode()
