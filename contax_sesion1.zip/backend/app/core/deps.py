"""
CONTAX - Dependencias de autenticación y autorización

Provee:
- get_current_user: extrae y valida el usuario desde el JWT
- require_role: decorador/dependency para restringir por rol
- get_tenant_schema: resuelve el schema del contador para el usuario actual
"""
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import decode_token
from app.models.global_models import Usuario, Contador, RolUsuario

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")


def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> Usuario:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Credenciales inválidas o expiradas",
        headers={"WWW-Authenticate": "Bearer"},
    )

    payload = decode_token(token)
    if payload is None or payload.get("type") != "access":
        raise credentials_exception

    user_id = payload.get("sub")
    if user_id is None:
        raise credentials_exception

    user = db.query(Usuario).filter(Usuario.id == int(user_id)).first()
    if user is None or not user.activo:
        raise credentials_exception

    return user


def require_roles(*roles: RolUsuario):
    """
    Dependency factory para restringir un endpoint a ciertos roles.

    Uso:
        @router.get("/admin-only")
        def endpoint(user: Usuario = Depends(require_roles(RolUsuario.SUPERADMIN))):
            ...
    """
    def checker(user: Usuario = Depends(get_current_user)) -> Usuario:
        if user.rol not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Acceso restringido. Rol requerido: {', '.join(r.value for r in roles)}"
            )
        return user
    return checker


def get_tenant_schema(
    user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> str:
    """
    Resuelve el schema de base de datos (tenant) correspondiente al usuario actual.

    - superadmin: no tiene un tenant fijo (debe especificar contador_id en la URL/query)
    - contador: usa su propio schema
    - cliente: usa el schema de su contador
    """
    if user.rol == RolUsuario.SUPERADMIN:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El superadmin debe especificar el contador_id explícitamente"
        )

    if user.contador_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Usuario sin contador asociado"
        )

    contador = db.query(Contador).filter(Contador.id == user.contador_id).first()
    if contador is None or not contador.activo:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Licencia inactiva o contador no encontrado"
        )

    return contador.schema_name


def get_tenant_schema_for_contador(contador_id: int, db: Session) -> str:
    """Helper directo (sin Depends) para resolver el schema de un contador por ID."""
    contador = db.query(Contador).filter(Contador.id == contador_id).first()
    if contador is None:
        raise HTTPException(status_code=404, detail="Contador no encontrado")
    return contador.schema_name
