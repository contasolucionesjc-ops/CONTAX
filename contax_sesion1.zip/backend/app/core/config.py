"""
CONTAX - Configuración central
Sistema contable y tributario multi-tenant para Ecuador
"""
import os
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # --- App ---
    APP_NAME: str = "CONTAX"
    APP_VERSION: str = "0.1.0"
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")

    # --- Database (Postgres, multi-tenant via schemas) ---
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL",
        "postgresql://contax:contax@localhost:5432/contax_db"
    )

    # --- Auth ---
    SECRET_KEY: str = os.getenv("SECRET_KEY", "CHANGE_ME_IN_PRODUCTION")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24h
    REFRESH_TOKEN_EXPIRE_DAYS: int = 30

    # --- CORS ---
    CORS_ORIGINS: list[str] = ["*"]  # Ajustar en producción

    # --- SRI Scraper ---
    SRI_LOGIN_URL: str = "https://srienlinea.sri.gob.ec/sri-en-linea/"
    SCRAPER_HEADLESS: bool = True
    SCRAPER_TIMEOUT_MS: int = 60000

    # --- Encriptación de credenciales SRI ---
    FERNET_KEY: str = os.getenv("FERNET_KEY", "")  # generar con Fernet.generate_key()

    class Config:
        env_file = ".env"


settings = Settings()
