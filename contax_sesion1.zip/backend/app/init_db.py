"""
CONTAX - Script de inicialización

Crea las tablas globales (schema public) y el usuario SUPERADMIN inicial.
Ejecutar una sola vez al desplegar:

    python -m app.init_db
"""
from sqlalchemy import text
from app.core.database import engine, Base, SessionLocal
from app.core.security import hash_password
from app.models import global_models  # noqa: F401 - registra los modelos en Base
from app.models.global_models import Usuario, RolUsuario


def init():
    print("Creando schema 'public' y tablas globales...")
    with engine.connect() as conn:
        conn.execute(text("CREATE SCHEMA IF NOT EXISTS public"))
        conn.commit()

    Base.metadata.create_all(bind=engine)
    print("✓ Tablas globales creadas (contadores, usuarios, logs_auditoria)")

    db = SessionLocal()
    try:
        existe = db.query(Usuario).filter(Usuario.rol == RolUsuario.SUPERADMIN).first()
        if existe:
            print(f"✓ Ya existe un superadmin: {existe.email}")
            return

        email = input("Email del superadmin (tú): ").strip()
        nombre = input("Nombre completo: ").strip()
        password = input("Contraseña: ").strip()

        admin = Usuario(
            nombre_completo=nombre,
            email=email,
            password_hash=hash_password(password),
            rol=RolUsuario.SUPERADMIN,
        )
        db.add(admin)
        db.commit()
        print(f"✓ Superadmin creado: {email}")
    finally:
        db.close()


if __name__ == "__main__":
    init()
