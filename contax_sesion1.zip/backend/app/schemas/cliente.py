"""CONTAX - Esquemas Pydantic para clientes (contribuyentes gestionados por un contador)."""
from pydantic import BaseModel, field_validator
from typing import Optional
from datetime import datetime
from app.models.tenant_models import TipoContribuyente, FrecuenciaSync


def calcular_noveno_digito(ruc: str) -> int:
    if len(ruc) < 9 or not ruc[:9].isdigit():
        return -1
    return int(ruc[8])


class ClienteCreate(BaseModel):
    ruc: str
    razon_social: str
    nombre_comercial: Optional[str] = None
    email: Optional[str] = None
    telefono: Optional[str] = None
    direccion: Optional[str] = None
    tipo_contribuyente: TipoContribuyente = TipoContribuyente.PERSONA_NATURAL_NO_OBLIGADA
    obligado_contabilidad: bool = False
    regimen_rimpe: bool = False
    sync_frecuencia: FrecuenciaSync = FrecuenciaSync.QUINCENAL
    sync_dia_preferido: Optional[int] = None

    # Credenciales SRI (texto plano en el request, se encriptan al guardar)
    sri_usuario: Optional[str] = None
    sri_clave: Optional[str] = None

    @field_validator("ruc")
    @classmethod
    def validar_ruc(cls, v):
        if len(v) != 13 or not v.isdigit():
            raise ValueError("El RUC debe tener 13 dígitos numéricos")
        return v


class ClienteUpdate(BaseModel):
    razon_social: Optional[str] = None
    nombre_comercial: Optional[str] = None
    email: Optional[str] = None
    telefono: Optional[str] = None
    direccion: Optional[str] = None
    tipo_contribuyente: Optional[TipoContribuyente] = None
    obligado_contabilidad: Optional[bool] = None
    regimen_rimpe: Optional[bool] = None
    sync_frecuencia: Optional[FrecuenciaSync] = None
    sync_dia_preferido: Optional[int] = None
    sri_usuario: Optional[str] = None
    sri_clave: Optional[str] = None  # si se envía, se re-encripta
    activo: Optional[bool] = None


class ClienteOut(BaseModel):
    id: int
    ruc: str
    razon_social: str
    nombre_comercial: Optional[str]
    email: Optional[str]
    telefono: Optional[str]
    direccion: Optional[str]
    tipo_contribuyente: TipoContribuyente
    obligado_contabilidad: bool
    regimen_rimpe: bool
    noveno_digito: Optional[int]
    sync_frecuencia: FrecuenciaSync
    sync_dia_preferido: Optional[int]
    sync_ultima_fecha: Optional[datetime]
    sync_ultimo_estado: Optional[str]
    tiene_credenciales_sri: bool = False
    activo: bool
    creado_en: datetime

    class Config:
        from_attributes = True
