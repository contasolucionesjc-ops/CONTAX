"""CONTAX - Esquemas Pydantic para gestión de contadores (licenciatarios)."""
from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime
from app.models.global_models import PlanLicencia


PLAN_LIMITES = {
    PlanLicencia.BASICO: 10,
    PlanLicencia.PROFESIONAL: 50,
    PlanLicencia.ESTUDIO: 999999,
}


class ContadorCreate(BaseModel):
    nombre_completo: str
    razon_social: Optional[str] = None
    ruc: Optional[str] = None
    email: EmailStr
    telefono: Optional[str] = None
    plan: PlanLicencia = PlanLicencia.BASICO
    password_inicial: str  # password del usuario "contador" que se crea junto con la licencia


class ContadorOut(BaseModel):
    id: int
    nombre_completo: str
    razon_social: Optional[str]
    ruc: Optional[str]
    email: EmailStr
    telefono: Optional[str]
    schema_name: str
    plan: PlanLicencia
    max_clientes: int
    activo: bool
    fecha_inicio_licencia: datetime
    fecha_vencimiento_licencia: Optional[datetime]
    total_clientes: int = 0  # calculado

    class Config:
        from_attributes = True


class ContadorUpdatePlan(BaseModel):
    plan: PlanLicencia
    activo: Optional[bool] = None
    fecha_vencimiento_licencia: Optional[datetime] = None
