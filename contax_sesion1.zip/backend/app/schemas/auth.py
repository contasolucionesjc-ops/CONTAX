"""CONTAX - Esquemas Pydantic para autenticación."""
from pydantic import BaseModel, EmailStr
from typing import Optional
from app.models.global_models import RolUsuario


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    rol: RolUsuario
    nombre_completo: str
    contador_id: Optional[int] = None
    cliente_ruc: Optional[str] = None


class RefreshRequest(BaseModel):
    refresh_token: str


class UsuarioCreate(BaseModel):
    nombre_completo: str
    email: EmailStr
    password: str
    rol: RolUsuario = RolUsuario.CLIENTE
    contador_id: Optional[int] = None
    cliente_ruc: Optional[str] = None


class UsuarioOut(BaseModel):
    id: int
    nombre_completo: str
    email: EmailStr
    rol: RolUsuario
    contador_id: Optional[int] = None
    cliente_ruc: Optional[str] = None
    activo: bool

    class Config:
        from_attributes = True
