"""
CONTAX - Modelos globales (schema 'public')

Estas tablas viven en el schema público y conocen a TODOS los contadores
(licenciatarios) de la plataforma. Son el "panel de licencias" de CONTAX.
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Enum, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.core.database import Base
import enum


class PlanLicencia(str, enum.Enum):
    BASICO = "basico"          # hasta 10 clientes
    PROFESIONAL = "profesional"  # hasta 50 clientes
    ESTUDIO = "estudio"        # ilimitado


class RolUsuario(str, enum.Enum):
    SUPERADMIN = "superadmin"   # Tú - dueño de CONTAX, ve todos los contadores
    CONTADOR = "contador"       # Licenciatario - administra sus propios clientes
    CLIENTE = "cliente"         # Usuario final - ve solo su propia info


class Contador(Base):
    """
    Un CONTADOR = un licenciatario de CONTAX (ej: tú, o tu colega).
    Cada contador tiene su propio schema de base de datos donde
    se guardan sus clientes, facturas, etc.
    """
    __tablename__ = "contadores"
    __table_args__ = {"schema": "public"}

    id = Column(Integer, primary_key=True, index=True)
    nombre_completo = Column(String(150), nullable=False)
    razon_social = Column(String(150), nullable=True)  # nombre del estudio contable
    ruc = Column(String(13), nullable=True)
    email = Column(String(150), unique=True, nullable=False, index=True)
    telefono = Column(String(20), nullable=True)

    # Identificador del schema de base de datos: "contador_1", "contador_2", etc.
    schema_name = Column(String(50), unique=True, nullable=False)

    # --- Licencia ---
    plan = Column(Enum(PlanLicencia), default=PlanLicencia.BASICO, nullable=False)
    max_clientes = Column(Integer, default=10, nullable=False)
    activo = Column(Boolean, default=True, nullable=False)
    fecha_inicio_licencia = Column(DateTime(timezone=True), server_default=func.now())
    fecha_vencimiento_licencia = Column(DateTime(timezone=True), nullable=True)

    creado_en = Column(DateTime(timezone=True), server_default=func.now())

    usuarios = relationship("Usuario", back_populates="contador", cascade="all, delete-orphan")


class Usuario(Base):
    """
    Usuario del sistema. Puede ser:
    - superadmin: tú, dueño de CONTAX (contador_id = NULL)
    - contador: dueño de una licencia (administra sus clientes)
    - cliente: usuario final que ve solo su propia info dentro del tenant del contador
    """
    __tablename__ = "usuarios"
    __table_args__ = {"schema": "public"}

    id = Column(Integer, primary_key=True, index=True)
    nombre_completo = Column(String(150), nullable=False)
    email = Column(String(150), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    rol = Column(Enum(RolUsuario), nullable=False, default=RolUsuario.CLIENTE)

    # Si rol = contador o cliente, pertenece a un contador (licenciatario)
    contador_id = Column(Integer, ForeignKey("public.contadores.id"), nullable=True)

    # Si rol = cliente, referencia al RUC del cliente dentro del schema del contador
    # (el detalle vive en el schema del tenant, esto es solo el puente)
    cliente_ruc = Column(String(13), nullable=True)

    activo = Column(Boolean, default=True, nullable=False)
    ultimo_login = Column(DateTime(timezone=True), nullable=True)
    creado_en = Column(DateTime(timezone=True), server_default=func.now())

    contador = relationship("Contador", back_populates="usuarios")


class LogAuditoria(Base):
    """Auditoría global - quién hizo qué y cuándo, a través de toda la plataforma."""
    __tablename__ = "logs_auditoria"
    __table_args__ = {"schema": "public"}

    id = Column(Integer, primary_key=True, index=True)
    usuario_id = Column(Integer, ForeignKey("public.usuarios.id"), nullable=True)
    contador_id = Column(Integer, ForeignKey("public.contadores.id"), nullable=True)
    accion = Column(String(100), nullable=False)  # "login", "sync_sri", "clasificar_factura", etc.
    detalle = Column(Text, nullable=True)
    ip_origen = Column(String(45), nullable=True)
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
