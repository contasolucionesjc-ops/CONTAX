"""
CONTAX - Modelos de TENANT (por contador)

Estas tablas se crean UNA VEZ POR CADA SCHEMA de contador
(ej: "contador_1", "contador_2"). Cada contador tiene su propia
copia aislada de estas tablas con sus propios clientes y datos.

IMPORTANTE: TenantBase es una metadata SEPARADA de Base (global),
para poder crear estas tablas dinámicamente en cualquier schema.
"""
from sqlalchemy import (
    Column, Integer, String, Boolean, DateTime, ForeignKey, Enum,
    Numeric, Text, Date, UniqueConstraint
)
from sqlalchemy.orm import relationship, declarative_base
from sqlalchemy.sql import func
import enum

TenantBase = declarative_base()


# =========================================================
# ENUMS - catálogos según normativa ecuatoriana
# =========================================================

class TipoContribuyente(str, enum.Enum):
    RIMPE_EMPRENDEDOR = "rimpe_emprendedor"
    RIMPE_NEGOCIO_POPULAR = "rimpe_negocio_popular"
    PERSONA_NATURAL_OBLIGADA = "persona_natural_obligada"
    PERSONA_NATURAL_NO_OBLIGADA = "persona_natural_no_obligada"
    SOCIEDAD = "sociedad"
    CONTRIBUYENTE_ESPECIAL = "contribuyente_especial"


class FrecuenciaSync(str, enum.Enum):
    MANUAL = "manual"
    SEMANAL = "semanal"
    QUINCENAL = "quincenal"
    MENSUAL = "mensual"


class TipoComprobante(str, enum.Enum):
    FACTURA = "01"
    NOTA_CREDITO = "04"
    NOTA_DEBITO = "05"
    GUIA_REMISION = "06"
    RETENCION = "07"
    LIQUIDACION_COMPRA = "03"


class CategoriaCompra(str, enum.Enum):
    INVENTARIO = "inventario"
    GASTO_OPERATIVO = "gasto"
    ACTIVO_FIJO = "activo"
    GASTO_PERSONAL = "personal"
    EXCLUIDA = "excluida"
    PENDIENTE = "pendiente"


# =========================================================
# CLIENTE (contribuyente gestionado por el contador)
# =========================================================

class Cliente(TenantBase):
    """
    Un contribuyente (RUC) gestionado por este contador.
    Ej: para tu colega, cada uno de sus 50 clientes es un registro aquí.
    """
    __tablename__ = "clientes"

    id = Column(Integer, primary_key=True, index=True)
    ruc = Column(String(13), unique=True, nullable=False, index=True)
    razon_social = Column(String(200), nullable=False)
    nombre_comercial = Column(String(200), nullable=True)
    email = Column(String(150), nullable=True)
    telefono = Column(String(20), nullable=True)
    direccion = Column(Text, nullable=True)

    tipo_contribuyente = Column(Enum(TipoContribuyente), nullable=False,
                                  default=TipoContribuyente.PERSONA_NATURAL_NO_OBLIGADA)
    obligado_contabilidad = Column(Boolean, default=False)
    regimen_rimpe = Column(Boolean, default=False)

    # 9no dígito del RUC (calculado) - define fechas de vencimiento
    noveno_digito = Column(Integer, nullable=True)

    # --- Credenciales SRI (encriptadas) ---
    sri_usuario = Column(String(20), nullable=True)  # normalmente = cédula/RUC
    sri_clave_encriptada = Column(Text, nullable=True)

    # --- Configuración de sync ---
    sync_frecuencia = Column(Enum(FrecuenciaSync), default=FrecuenciaSync.QUINCENAL)
    sync_dia_preferido = Column(Integer, nullable=True)  # día del mes preferido
    sync_ultima_fecha = Column(DateTime(timezone=True), nullable=True)
    sync_ultimo_estado = Column(String(20), nullable=True)  # "ok", "error", "pendiente"
    sync_ultimo_error = Column(Text, nullable=True)

    activo = Column(Boolean, default=True)
    creado_en = Column(DateTime(timezone=True), server_default=func.now())

    documentos = relationship("DocumentoElectronico", back_populates="cliente", cascade="all, delete-orphan")
    proveedores = relationship("ProveedorRecurrente", back_populates="cliente", cascade="all, delete-orphan")


# =========================================================
# DOCUMENTOS ELECTRÓNICOS (facturas emitidas/recibidas, NC, retenciones...)
# =========================================================

class DocumentoElectronico(TenantBase):
    """
    Un comprobante electrónico (factura, NC, retención, etc.)
    Puede ser EMITIDO (cliente es el vendedor) o RECIBIDO (cliente es el comprador).
    """
    __tablename__ = "documentos_electronicos"
    __table_args__ = (
        UniqueConstraint("cliente_id", "clave_acceso", name="uq_doc_cliente_clave"),
    )

    id = Column(Integer, primary_key=True, index=True)
    cliente_id = Column(Integer, ForeignKey("clientes.id"), nullable=False, index=True)

    clave_acceso = Column(String(49), nullable=False, index=True)
    tipo_comprobante = Column(Enum(TipoComprobante), nullable=False)
    direccion = Column(String(10), nullable=False)  # "emitido" | "recibido"

    secuencial = Column(String(15), nullable=True)
    fecha_emision = Column(Date, nullable=False)
    estado_sri = Column(String(20), default="AUTORIZADO")
    fecha_autorizacion = Column(DateTime(timezone=True), nullable=True)

    # Contraparte (emisor si recibido, comprador si emitido)
    contraparte_ruc = Column(String(13), nullable=True, index=True)
    contraparte_razon_social = Column(String(200), nullable=True)

    base_imponible = Column(Numeric(14, 2), default=0)
    base_imponible_0 = Column(Numeric(14, 2), default=0)
    iva_tarifa = Column(Numeric(5, 2), default=15)
    iva_valor = Column(Numeric(14, 2), default=0)
    importe_total = Column(Numeric(14, 2), default=0)
    forma_pago = Column(String(5), nullable=True)

    descripcion = Column(Text, nullable=True)  # concatenación de items
    xml_raw = Column(Text, nullable=True)  # XML original guardado para auditoría

    # --- Clasificación (solo aplica a documentos RECIBIDOS) ---
    categoria = Column(Enum(CategoriaCompra), nullable=True)
    categoria_razon = Column(String(200), nullable=True)  # por qué se clasificó así
    categoria_nota = Column(Text, nullable=True)  # nota manual del contador

    # --- Generado por sync o importación manual ---
    origen = Column(String(20), default="sync")  # "sync" | "manual_xml" | "manual_zip"

    creado_en = Column(DateTime(timezone=True), server_default=func.now())

    cliente = relationship("Cliente", back_populates="documentos")
    detalles = relationship("DetalleDocumento", back_populates="documento", cascade="all, delete-orphan")


class DetalleDocumento(TenantBase):
    """Línea de detalle (producto/servicio) de un documento electrónico."""
    __tablename__ = "detalles_documento"

    id = Column(Integer, primary_key=True, index=True)
    documento_id = Column(Integer, ForeignKey("documentos_electronicos.id"), nullable=False)

    codigo_principal = Column(String(50), nullable=True)
    descripcion = Column(String(300), nullable=False)
    cantidad = Column(Numeric(14, 6), default=1)
    precio_unitario = Column(Numeric(14, 6), default=0)
    descuento = Column(Numeric(14, 2), default=0)
    precio_total_sin_impuesto = Column(Numeric(14, 2), default=0)

    documento = relationship("DocumentoElectronico", back_populates="detalles")


# =========================================================
# PROVEEDORES / CLIENTES RECURRENTES (para clasificación automática)
# =========================================================

class ProveedorRecurrente(TenantBase):
    """
    Proveedor conocido de un cliente, con categoría pre-asignada.
    Ej: "PLASTIGAMA S.A." (RUC X) siempre se clasifica como inventario
    para el cliente "Espejos y Luces".
    """
    __tablename__ = "proveedores_recurrentes"
    __table_args__ = (
        UniqueConstraint("cliente_id", "proveedor_ruc", name="uq_proveedor_cliente"),
    )

    id = Column(Integer, primary_key=True, index=True)
    cliente_id = Column(Integer, ForeignKey("clientes.id"), nullable=False, index=True)

    proveedor_ruc = Column(String(13), nullable=False)
    proveedor_nombre = Column(String(200), nullable=True)
    categoria_default = Column(Enum(CategoriaCompra), nullable=False)
    nota = Column(Text, nullable=True)

    creado_en = Column(DateTime(timezone=True), server_default=func.now())

    cliente = relationship("Cliente", back_populates="proveedores")


# =========================================================
# REGLAS DE CLASIFICACIÓN POR PALABRA CLAVE
# =========================================================

class ReglaClasificacion(TenantBase):
    """
    Regla automática: si la descripción o el proveedor contiene
    cierta palabra clave, clasificar en cierta categoría.
    Las reglas pueden ser globales (cliente_id NULL) o específicas de un cliente.
    """
    __tablename__ = "reglas_clasificacion"

    id = Column(Integer, primary_key=True, index=True)
    cliente_id = Column(Integer, ForeignKey("clientes.id"), nullable=True)  # NULL = regla global del contador

    palabra_clave = Column(String(100), nullable=False)
    tipo_busqueda = Column(String(20), default="descripcion")  # "descripcion" | "proveedor"
    categoria = Column(Enum(CategoriaCompra), nullable=False)
    prioridad = Column(Integer, default=100)  # menor = mayor prioridad

    activo = Column(Boolean, default=True)
    creado_en = Column(DateTime(timezone=True), server_default=func.now())


# =========================================================
# ASIENTOS CONTABLES (generados automáticamente)
# =========================================================

class AsientoContable(TenantBase):
    """Asiento de diario generado a partir de un documento electrónico."""
    __tablename__ = "asientos_contables"

    id = Column(Integer, primary_key=True, index=True)
    cliente_id = Column(Integer, ForeignKey("clientes.id"), nullable=False, index=True)
    documento_id = Column(Integer, ForeignKey("documentos_electronicos.id"), nullable=True)

    fecha = Column(Date, nullable=False)
    descripcion = Column(String(300), nullable=False)
    numero = Column(Integer, nullable=False)

    creado_en = Column(DateTime(timezone=True), server_default=func.now())

    lineas = relationship("LineaAsiento", back_populates="asiento", cascade="all, delete-orphan")


class LineaAsiento(TenantBase):
    """Línea (débito o crédito) de un asiento contable."""
    __tablename__ = "lineas_asiento"

    id = Column(Integer, primary_key=True, index=True)
    asiento_id = Column(Integer, ForeignKey("asientos_contables.id"), nullable=False)

    codigo_cuenta = Column(String(20), nullable=False)  # ej: "1.1.02"
    nombre_cuenta = Column(String(150), nullable=False)
    debe = Column(Numeric(14, 2), default=0)
    haber = Column(Numeric(14, 2), default=0)

    asiento = relationship("AsientoContable", back_populates="lineas")


# =========================================================
# CALENDARIO TRIBUTARIO / ALERTAS
# =========================================================

class AlertaTributaria(TenantBase):
    """
    Alerta generada por el sistema para un cliente:
    vencimientos próximos, facturas pendientes de clasificar, errores de sync, etc.
    """
    __tablename__ = "alertas_tributarias"

    id = Column(Integer, primary_key=True, index=True)
    cliente_id = Column(Integer, ForeignKey("clientes.id"), nullable=False, index=True)

    tipo = Column(String(50), nullable=False)  # "vencimiento_iva", "pendientes_clasificar", "sync_error", etc.
    titulo = Column(String(200), nullable=False)
    descripcion = Column(Text, nullable=True)
    severidad = Column(String(20), default="info")  # "info" | "warning" | "danger"
    fecha_referencia = Column(Date, nullable=True)  # ej: fecha límite de declaración

    resuelta = Column(Boolean, default=False)
    creado_en = Column(DateTime(timezone=True), server_default=func.now())


# =========================================================
# LOG DE SYNC (auditoría de sincronizaciones con el SRI)
# =========================================================

class LogSync(TenantBase):
    """Registro de cada intento de sincronización con el SRI."""
    __tablename__ = "logs_sync"

    id = Column(Integer, primary_key=True, index=True)
    cliente_id = Column(Integer, ForeignKey("clientes.id"), nullable=False, index=True)

    fecha_inicio = Column(DateTime(timezone=True), server_default=func.now())
    fecha_fin = Column(DateTime(timezone=True), nullable=True)
    estado = Column(String(20), default="en_progreso")  # "en_progreso" | "ok" | "error"
    documentos_nuevos = Column(Integer, default=0)
    documentos_emitidos = Column(Integer, default=0)
    documentos_recibidos = Column(Integer, default=0)
    error_detalle = Column(Text, nullable=True)
    periodo_desde = Column(Date, nullable=True)
    periodo_hasta = Column(Date, nullable=True)
