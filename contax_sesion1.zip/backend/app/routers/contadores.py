"""
CONTAX - Router de gestión de contadores (licenciatarios)

Solo accesible por SUPERADMIN. Este es el "panel de licencias":
crear nuevos contadores (licencias), cambiar de plan, activar/desactivar,
y ver cuántos clientes tiene cada uno.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import text

from app.core.database import get_db, create_tenant_schema, tenant_session
from app.core.deps import require_roles
from app.core.security import hash_password
from app.models.global_models import Contador, Usuario, RolUsuario
from app.models.tenant_models import Cliente
from app.schemas.contador import ContadorCreate, ContadorOut, ContadorUpdatePlan, PLAN_LIMITES

router = APIRouter(prefix="/contadores", tags=["Contadores (Licencias)"])


@router.post("", response_model=ContadorOut, status_code=status.HTTP_201_CREATED)
def crear_contador(
    payload: ContadorCreate,
    db: Session = Depends(get_db),
    _admin: Usuario = Depends(require_roles(RolUsuario.SUPERADMIN)),
):
    """
    Crea una nueva licencia CONTAX:
    1. Registra el contador en la tabla global
    2. Crea su schema dedicado en Postgres con todas las tablas de tenant
    3. Crea el usuario 'contador' que usará para iniciar sesión
    """
    existente = db.query(Contador).filter(Contador.email == payload.email).first()
    if existente:
        raise HTTPException(status_code=400, detail="Ya existe un contador con ese email")

    # Crear registro de contador (sin schema_name aún, se asigna tras obtener el ID)
    contador = Contador(
        nombre_completo=payload.nombre_completo,
        razon_social=payload.razon_social,
        ruc=payload.ruc,
        email=payload.email,
        telefono=payload.telefono,
        plan=payload.plan,
        max_clientes=PLAN_LIMITES[payload.plan],
        schema_name="temp",  # placeholder
    )
    db.add(contador)
    db.flush()  # para obtener el ID sin hacer commit completo aún

    schema_name = f"contador_{contador.id}"
    contador.schema_name = schema_name

    # Crear usuario contador
    usuario = Usuario(
        nombre_completo=payload.nombre_completo,
        email=payload.email,
        password_hash=hash_password(payload.password_inicial),
        rol=RolUsuario.CONTADOR,
        contador_id=contador.id,
    )
    db.add(usuario)
    db.commit()

    # Crear schema físico + tablas de tenant
    create_tenant_schema(schema_name)

    result = ContadorOut.from_orm(contador)
    result.total_clientes = 0
    return result


@router.get("", response_model=list[ContadorOut])
def listar_contadores(
    db: Session = Depends(get_db),
    _admin: Usuario = Depends(require_roles(RolUsuario.SUPERADMIN)),
):
    """Lista todos los contadores (licenciatarios) con su cantidad de clientes."""
    contadores = db.query(Contador).all()
    out = []
    for c in contadores:
        total = 0
        try:
            with tenant_session(c.schema_name) as tdb:
                total = tdb.query(Cliente).count()
        except Exception:
            total = 0
        item = ContadorOut.from_orm(c)
        item.total_clientes = total
        out.append(item)
    return out


@router.get("/{contador_id}", response_model=ContadorOut)
def obtener_contador(
    contador_id: int,
    db: Session = Depends(get_db),
    _admin: Usuario = Depends(require_roles(RolUsuario.SUPERADMIN)),
):
    contador = db.query(Contador).filter(Contador.id == contador_id).first()
    if not contador:
        raise HTTPException(status_code=404, detail="Contador no encontrado")

    total = 0
    with tenant_session(contador.schema_name) as tdb:
        total = tdb.query(Cliente).count()

    item = ContadorOut.from_orm(contador)
    item.total_clientes = total
    return item


@router.patch("/{contador_id}/plan", response_model=ContadorOut)
def actualizar_plan(
    contador_id: int,
    payload: ContadorUpdatePlan,
    db: Session = Depends(get_db),
    _admin: Usuario = Depends(require_roles(RolUsuario.SUPERADMIN)),
):
    """Cambia el plan de licencia, activa/desactiva, o ajusta fecha de vencimiento."""
    contador = db.query(Contador).filter(Contador.id == contador_id).first()
    if not contador:
        raise HTTPException(status_code=404, detail="Contador no encontrado")

    contador.plan = payload.plan
    contador.max_clientes = PLAN_LIMITES[payload.plan]
    if payload.activo is not None:
        contador.activo = payload.activo
    if payload.fecha_vencimiento_licencia is not None:
        contador.fecha_vencimiento_licencia = payload.fecha_vencimiento_licencia

    db.commit()

    total = 0
    with tenant_session(contador.schema_name) as tdb:
        total = tdb.query(Cliente).count()

    item = ContadorOut.from_orm(contador)
    item.total_clientes = total
    return item


@router.delete("/{contador_id}", status_code=status.HTTP_204_NO_CONTENT)
def eliminar_contador(
    contador_id: int,
    db: Session = Depends(get_db),
    _admin: Usuario = Depends(require_roles(RolUsuario.SUPERADMIN)),
):
    """
    Desactiva un contador (NO elimina su schema/datos por seguridad).
    Para borrar físicamente el schema, hacerlo manualmente desde la BD.
    """
    contador = db.query(Contador).filter(Contador.id == contador_id).first()
    if not contador:
        raise HTTPException(status_code=404, detail="Contador no encontrado")

    contador.activo = False
    db.query(Usuario).filter(Usuario.contador_id == contador_id).update({"activo": False})
    db.commit()
    return None
