"""
CONTAX - Router de clientes (contribuyentes)

Cada CONTADOR (licenciatario) gestiona sus propios clientes dentro
de su schema aislado. El número máximo de clientes está limitado
por su plan (PLAN_LIMITES).
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session as SASession

from app.core.database import get_db, tenant_session
from app.core.deps import get_current_user, get_tenant_schema, require_roles
from app.core.security import encriptar_clave_sri
from app.models.global_models import Usuario, Contador, RolUsuario
from app.models.tenant_models import Cliente
from app.schemas.cliente import ClienteCreate, ClienteUpdate, ClienteOut, calcular_noveno_digito

router = APIRouter(prefix="/clientes", tags=["Clientes"])


def _to_out(cliente: Cliente) -> ClienteOut:
    out = ClienteOut.from_orm(cliente)
    out.tiene_credenciales_sri = bool(cliente.sri_clave_encriptada)
    return out


@router.post("", response_model=ClienteOut, status_code=status.HTTP_201_CREATED)
def crear_cliente(
    payload: ClienteCreate,
    schema_name: str = Depends(get_tenant_schema),
    user: Usuario = Depends(require_roles(RolUsuario.CONTADOR)),
    global_db: SASession = Depends(get_db),
):
    """Registra un nuevo contribuyente dentro del tenant del contador actual."""
    # Verificar límite de plan
    contador = global_db.query(Contador).filter(Contador.id == user.contador_id).first()

    with tenant_session(schema_name) as db:
        total_actual = db.query(Cliente).count()
        if total_actual >= contador.max_clientes:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=(
                    f"Has alcanzado el límite de {contador.max_clientes} clientes "
                    f"de tu plan ({contador.plan.value}). Actualiza tu licencia para agregar más."
                )
            )

        existente = db.query(Cliente).filter(Cliente.ruc == payload.ruc).first()
        if existente:
            raise HTTPException(status_code=400, detail="Ya existe un cliente con ese RUC")

        cliente = Cliente(
            ruc=payload.ruc,
            razon_social=payload.razon_social,
            nombre_comercial=payload.nombre_comercial,
            email=payload.email,
            telefono=payload.telefono,
            direccion=payload.direccion,
            tipo_contribuyente=payload.tipo_contribuyente,
            obligado_contabilidad=payload.obligado_contabilidad,
            regimen_rimpe=payload.regimen_rimpe,
            noveno_digito=calcular_noveno_digito(payload.ruc),
            sync_frecuencia=payload.sync_frecuencia,
            sync_dia_preferido=payload.sync_dia_preferido,
            sri_usuario=payload.sri_usuario,
        )

        if payload.sri_clave:
            cliente.sri_clave_encriptada = encriptar_clave_sri(payload.sri_clave)

        db.add(cliente)
        db.commit()
        db.refresh(cliente)
        return _to_out(cliente)


@router.get("", response_model=list[ClienteOut])
def listar_clientes(
    schema_name: str = Depends(get_tenant_schema),
    user: Usuario = Depends(require_roles(RolUsuario.CONTADOR)),
):
    """Lista todos los contribuyentes del contador actual."""
    with tenant_session(schema_name) as db:
        clientes = db.query(Cliente).order_by(Cliente.razon_social).all()
        return [_to_out(c) for c in clientes]


@router.get("/{cliente_id}", response_model=ClienteOut)
def obtener_cliente(
    cliente_id: int,
    schema_name: str = Depends(get_tenant_schema),
    user: Usuario = Depends(get_current_user),
):
    """
    Obtiene un cliente. Accesible por:
    - el contador dueño del tenant
    - el usuario 'cliente' correspondiente (solo su propio registro)
    """
    with tenant_session(schema_name) as db:
        cliente = db.query(Cliente).filter(Cliente.id == cliente_id).first()
        if not cliente:
            raise HTTPException(status_code=404, detail="Cliente no encontrado")

        if user.rol == RolUsuario.CLIENTE and user.cliente_ruc != cliente.ruc:
            raise HTTPException(status_code=403, detail="No autorizado")

        return _to_out(cliente)


@router.patch("/{cliente_id}", response_model=ClienteOut)
def actualizar_cliente(
    cliente_id: int,
    payload: ClienteUpdate,
    schema_name: str = Depends(get_tenant_schema),
    user: Usuario = Depends(require_roles(RolUsuario.CONTADOR)),
):
    with tenant_session(schema_name) as db:
        cliente = db.query(Cliente).filter(Cliente.id == cliente_id).first()
        if not cliente:
            raise HTTPException(status_code=404, detail="Cliente no encontrado")

        data = payload.dict(exclude_unset=True)
        sri_clave = data.pop("sri_clave", None)

        for field, value in data.items():
            setattr(cliente, field, value)

        if sri_clave:
            cliente.sri_clave_encriptada = encriptar_clave_sri(sri_clave)

        db.commit()
        db.refresh(cliente)
        return _to_out(cliente)


@router.delete("/{cliente_id}", status_code=status.HTTP_204_NO_CONTENT)
def eliminar_cliente(
    cliente_id: int,
    schema_name: str = Depends(get_tenant_schema),
    user: Usuario = Depends(require_roles(RolUsuario.CONTADOR)),
):
    """Desactiva (no borra) un cliente para preservar histórico."""
    with tenant_session(schema_name) as db:
        cliente = db.query(Cliente).filter(Cliente.id == cliente_id).first()
        if not cliente:
            raise HTTPException(status_code=404, detail="Cliente no encontrado")
        cliente.activo = False
        db.commit()
    return None
